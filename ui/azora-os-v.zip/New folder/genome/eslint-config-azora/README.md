# ESLint Config Azora

This package contains the ESLint configuration for Azora.