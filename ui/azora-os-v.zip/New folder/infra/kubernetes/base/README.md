# Kubernetes Base

This directory contains the base configurations for Kubernetes.